// =========================================================
// PARSER.JS — Browser-side PDF & DOCX parsing
// Uses PDF.js (loaded via CDN) and mammoth.js (loaded via CDN)
// =========================================================

const ResumeParser = {
  /**
   * Main entry point: auto-detect file type and parse
   * @param {File} file - The uploaded file
   * @returns {Promise<string>} - Extracted plain text
   */
  async parse(file) {
    const ext = file.name.split('.').pop().toLowerCase();
    if (ext === 'pdf') {
      return await this.parsePDF(file);
    } else if (ext === 'docx' || ext === 'doc') {
      return await this.parseDOCX(file);
    } else if (ext === 'txt') {
      return await this.parseTXT(file);
    } else {
      throw new Error(`Unsupported file type: .${ext}. Please upload PDF, DOCX, or TXT.`);
    }
  },

  /**
   * Parse PDF using PDF.js
   */
  async parsePDF(file) {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;

    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items
        .map(item => item.str)
        .join(' ')
        .replace(/\s{2,}/g, ' ')
        .trim();
      fullText += pageText + '\n\n';
    }

    return this.cleanText(fullText);
  },

  /**
   * Parse DOCX using mammoth.js
   */
  async parseDOCX(file) {
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    return this.cleanText(result.value);
  },

  /**
   * Parse plain text file
   */
  async parseTXT(file) {
    const text = await file.text();
    return this.cleanText(text);
  },

  /**
   * Clean extracted text
   */
  cleanText(text) {
    return text
      .replace(/\r\n/g, '\n')
      .replace(/\r/g, '\n')
      .replace(/\t/g, ' ')
      .replace(/[ ]{3,}/g, '  ')
      .replace(/\n{4,}/g, '\n\n\n')
      .trim();
  }
};
