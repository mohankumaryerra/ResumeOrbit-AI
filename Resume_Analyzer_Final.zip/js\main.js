// =========================================================
// MAIN.JS — Landing page logic
// Handles: API key, file upload, drag-drop, form, analysis
// =========================================================

(function () {
  'use strict';

  // ── DOM refs ──
  const resumeInput = document.getElementById('resumeInput');
  const resumeZone  = document.getElementById('resumeZone');
  const resumeFileName = document.getElementById('resumeFileName');
  const jdInput     = document.getElementById('jdInput');
  const roleSelect  = document.getElementById('roleSelect');
  const analyzeBtn  = document.getElementById('analyzeBtn');
  const sampleBtn   = document.getElementById('sampleBtn');
  const errorToast  = document.getElementById('errorToast');
  const errorMsg    = document.getElementById('errorMsg');
  const recentSection = document.getElementById('recentAnalysesSection');
  const recentList  = document.getElementById('recentAnalysesList');

  let resumeFile = null;

  (function init() {
    loadHistory();
  })();

  // ── File Upload ──
  if (resumeInput) {
    resumeInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) handleFileSelected(file);
    });
  }

  // Drag & drop
  if (resumeZone) {
    resumeZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      resumeZone.classList.add('drag-over');
    });
    resumeZone.addEventListener('dragleave', () => {
      resumeZone.classList.remove('drag-over');
    });
    resumeZone.addEventListener('drop', (e) => {
      e.preventDefault();
      resumeZone.classList.remove('drag-over');
      const file = e.dataTransfer.files[0];
      if (file) handleFileSelected(file);
    });
  }

  function handleFileSelected(file) {
    const validTypes = ['pdf', 'docx', 'doc', 'txt'];
    const ext = file.name.split('.').pop().toLowerCase();
    if (!validTypes.includes(ext)) {
      return showError(`Invalid file type. Please upload PDF, DOCX, or TXT.`);
    }
    if (file.size > 10 * 1024 * 1024) {
      return showError('File too large. Maximum size is 10MB.');
    }
    resumeFile = file;
    resumeZone.classList.add('has-file');
    if (resumeFileName) {
      resumeFileName.textContent = `📎 ${file.name} (${formatBytes(file.size)})`;
      resumeFileName.classList.add('visible');
    }
    // Update icon
    const icon = resumeZone.querySelector('.upload-icon');
    if (icon) icon.textContent = '✅';
  }

  // ── Analyze ──
  if (analyzeBtn) {
    analyzeBtn.addEventListener('click', handleAnalyze);
  }
  
  if (sampleBtn) {
    sampleBtn.addEventListener('click', handleSampleData);
  }

  function handleSampleData() {
    const mockAnalysis = {
      "ats_score": 88,
      "clarity_score": 92,
      "impact_score": 85,
      "jd_match_score": 80,
      "overall_grade": "A",
      "recruiter_summary": "Strong engineering profile with excellent full-stack experience. The candidate demonstrates a solid track record of delivering scalable web applications and optimizing performance. A great fit for Senior Frontend or Full Stack roles.",
      "strengths": [
        "Extensive experience with modern JavaScript frameworks (React, Vue).",
        "Proven ability to lead technical initiatives and mentor junior developers.",
        "Strong understanding of CI/CD pipelines and cloud deployments."
      ],
      "missing_keywords": ["GraphQL", "Docker", "Kubernetes", "Microservices architecture"],
      "present_keywords": ["React", "TypeScript", "Node.js", "AWS", "Agile", "REST APIs"],
      "skill_gaps": ["GraphQL API Design", "Container Orchestration (Kubernetes)"],
      "weak_bullets": [
        {
          "original": "Worked on the main company website using React.",
          "improved": "Developed and maintained the core customer-facing web application using React, serving 50k+ monthly active users and decreasing page load times by 25%.",
          "reason": "Added specific metrics (50k+ users, 25% load time decrease) and strong action verbs (Developed, maintained) to demonstrate impact."
        },
        {
          "original": "Helped team build new features.",
          "improved": "Collaborated with a cross-functional team of 6 engineers to deliver 4 major product features ahead of schedule, driving a 15% increase in user engagement.",
          "reason": "Quantified team size and business impact (15% increase in engagement) to make the achievement tangible."
        }
      ],
      "top_suggestions": [
        {
          "priority": "high",
          "category": "keywords",
          "suggestion": "Incorporate more backend and DevOps keywords (e.g., Docker, Kubernetes) if targeting Full Stack roles."
        },
        {
          "priority": "medium",
          "category": "impact",
          "suggestion": "Quantify your achievements in the 'Education' section, such as GPA or specific notable projects."
        },
        {
          "priority": "low",
          "category": "formatting",
          "suggestion": "Ensure consistent date formatting (e.g., MM/YYYY) across all experience entries."
        }
      ],
      "section_scores": {
        "experience": 90,
        "education": 85,
        "skills": 95,
        "formatting": 80
      },
      "suggested_roles": [
        "Senior Frontend Engineer",
        "Full Stack Developer",
        "Engineering Manager",
        "React Native Developer"
      ],
      "interview_questions": [
        "Can you describe a time you optimized the performance of a React application? What strategies did you use?",
        "How do you approach mentoring junior developers and leading technical initiatives?",
        "Tell me about your experience deploying applications to AWS.",
        "How would you integrate GraphQL into our existing REST architecture?"
      ]
    };

    const payload = {
      analysis: mockAnalysis,
      meta: {
        fileName: 'Jane_Doe_Resume_Sample.pdf',
        targetRole: 'Senior Frontend Engineer',
        hasJD: true,
        timestamp: new Date().toISOString()
      }
    };
    
    saveToHistory(payload);
    sessionStorage.setItem('resume_analysis', JSON.stringify(payload));
    window.location.href = 'results.html';
  }

  async function handleAnalyze() {
    // No API key needed for local Ollama
    if (!resumeFile) return showError('Please upload your resume first.');

    setLoading(true);

    try {
      // 1. Parse resume file
      const resumeText = await ResumeParser.parse(resumeFile);
      if (!resumeText || resumeText.length < 100) {
        throw new Error('Could not extract text from resume. Please try a different file.');
      }

      // 2. Get values
      const jd = jdInput?.value?.trim() || '';
      const role = roleSelect?.value || '';

      // 3. Call Gemini AI
      const analysis = await AI_API.analyzeResume(resumeText, jd, role);

      // 4. Store and redirect
      const payload = {
        analysis,
        meta: {
          fileName: resumeFile.name,
          targetRole: role,
          hasJD: !!jd,
          timestamp: new Date().toISOString()
        }
      };
      
      saveToHistory(payload);
      sessionStorage.setItem('resume_analysis', JSON.stringify(payload));
      window.location.href = 'results.html';

    } catch (err) {
      setLoading(false);
      showError(err.message || 'Analysis failed. Please try again.');
      console.error(err);
    }
  }

  // ── Helpers ──
  function setLoading(state) {
    if (!analyzeBtn) return;
    analyzeBtn.disabled = state;
    analyzeBtn.classList.toggle('loading', state);
  }

  function showError(msg) {
    if (!errorToast || !errorMsg) { alert(msg); return; }
    errorMsg.textContent = msg;
    errorToast.classList.add('show');
    clearTimeout(window._errTimeout);
    window._errTimeout = setTimeout(() => errorToast.classList.remove('show'), 5000);
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1024 / 1024).toFixed(1) + ' MB';
  }

  // ── Dismiss error on click ──
  if (errorToast) {
    errorToast.addEventListener('click', () => errorToast.classList.remove('show'));
  }

  // ── History ──
  function saveToHistory(payload) {
    let history = [];
    try {
      history = JSON.parse(localStorage.getItem('resume_history') || '[]');
    } catch(e) {}
    
    // Add to beginning
    history.unshift(payload);
    
    // Keep only last 5
    if (history.length > 5) {
      history = history.slice(0, 5);
    }
    
    localStorage.setItem('resume_history', JSON.stringify(history));
  }

  function loadHistory() {
    if (!recentSection || !recentList) return;
    
    let history = [];
    try {
      history = JSON.parse(localStorage.getItem('resume_history') || '[]');
    } catch(e) {}
    
    if (history.length === 0) {
      recentSection.style.display = 'none';
      return;
    }
    
    recentSection.style.display = 'block';
    recentList.innerHTML = history.map((item, index) => {
      const dt = new Date(item.meta.timestamp).toLocaleString();
      const grade = item.analysis.overall_grade || '?';
      return `
        <div class="glass-card" style="padding: 16px 20px; display: flex; align-items: center; justify-content: space-between; cursor: pointer; transition: transform 0.2s; border-radius: 12px;" onclick="window.loadHistoryItem(${index})">
          <div style="display: flex; align-items: center; gap: 16px;">
            <div style="width: 40px; height: 40px; border-radius: 8px; background: rgba(124,58,237,0.15); color: var(--violet-400); display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 16px;">
              ${grade}
            </div>
            <div>
              <div style="font-weight: 600; color: var(--text-primary); font-size: 14px;">${item.meta.fileName}</div>
              <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                ${dt} ${item.meta.targetRole ? `· Targeted for: ${item.meta.targetRole}` : ''}
              </div>
            </div>
          </div>
          <button class="btn-secondary" style="padding: 6px 12px; font-size: 12px;">View Report</button>
        </div>
      `;
    }).join('');
  }

  window.loadHistoryItem = function(index) {
    let history = [];
    try {
      history = JSON.parse(localStorage.getItem('resume_history') || '[]');
    } catch(e) {}
    
    if (history[index]) {
      sessionStorage.setItem('resume_analysis', JSON.stringify(history[index]));
      window.location.href = 'results.html';
    }
  };

})();
