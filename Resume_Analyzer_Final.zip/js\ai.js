// =========================================================
// AI_API — Google Gemini Integration
// =========================================================

const AI_API = {
  async analyzeResume(resumeText, jobDescription = '', targetRole = '') {
    const prompt = this.buildAnalysisPrompt(resumeText, jobDescription, targetRole);

    if (!CONFIG.GEMINI_API_KEY || CONFIG.GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
      throw new Error('Please set your Gemini API key in js/config.js. Get one free at https://aistudio.google.com/apikey');
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${CONFIG.MODEL_NAME}:generateContent?key=${CONFIG.GEMINI_API_KEY}`;

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: 'You are an expert ATS (Applicant Tracking System) and career coach. Your task is to analyze resumes and provide detailed, actionable feedback in JSON format. Return ONLY the JSON object.\n\n' + prompt
                }
              ]
            }
          ],
          generationConfig: {
            temperature: 0.7,
            responseMimeType: 'application/json'
          }
        })
      });

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Gemini API Error: ${response.status} - ${errText}`);
      }

      const data = await response.json();
      const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
      return this.parseJSON(raw);

    } catch (e) {
      console.error('Gemini API Call Failed:', e);
      throw new Error(e.message || 'Could not connect to Google Gemini API. Check your API key and internet connection.');
    }
  },

  parseJSON(raw) {
    if (!raw) throw new Error('AI returned an empty response.');
    try {
      let cleaned = raw.replace(/```json\s?/g, '').replace(/```\s?/g, '').trim();
      return JSON.parse(cleaned);
    } catch (e) {
      const start = raw.indexOf('{');
      const end = raw.lastIndexOf('}');
      if (start !== -1 && end !== -1) {
        try {
          return JSON.parse(raw.substring(start, end + 1));
        } catch (e2) {}
      }
      throw new Error('Invalid AI response format.');
    }
  },

  buildAnalysisPrompt(resumeText, jobDescription, targetRole) {
    return `Analyze this resume and return a JSON object.
${targetRole ? `Role: ${targetRole}` : ''}
${jobDescription ? `JD: ${jobDescription}` : ''}
Resume: ${resumeText}

Return ONLY JSON:
{
  "ats_score": 0-100,
  "clarity_score": 0-100,
  "impact_score": 0-100,
  "jd_match_score": ${jobDescription ? '0-100' : 'null'},
  "overall_grade": "A to D",
  "recruiter_summary": "string",
  "strengths": ["string"],
  "missing_keywords": ["string"],
  "present_keywords": ["string"],
  "skill_gaps": ["string"],
  "weak_bullets": [{"original": "string", "improved": "string", "reason": "string"}],
  "top_suggestions": [{"priority": "string", "category": "string", "suggestion": "string"}],
  "section_scores": {"experience": 0-100, "education": 0-100, "skills": 0-100, "formatting": 0-100},
  "suggested_roles": ["string"],
  "interview_questions": ["string"]
}`;
  }
};
