/**
 * CONFIG.JS
 * Place your sensitive configuration here.
 */

const CONFIG = {
  // Google Gemini API Key — Get yours at https://aistudio.google.com/apikey
  GEMINI_API_KEY: 'AQ.Ab8RN6JrX3wVUbMJaY_W9EmhZjqiN7QexAHpCcPEjXrV7Bpzrw',
  // Gemini Model Name
  MODEL_NAME: 'gemini-2.0-flash'
};
