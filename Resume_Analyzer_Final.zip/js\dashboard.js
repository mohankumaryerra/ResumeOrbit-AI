// =========================================================
// DASHBOARD.JS — Results page rendering
// Reads sessionStorage, renders all analysis data
// =========================================================

(function () {
  'use strict';

  // ── Load Data ──
  const raw = sessionStorage.getItem('resume_analysis');
  if (!raw) {
    window.location.href = 'index.html';
    return;
  }

  const { analysis: A, meta } = JSON.parse(raw);

  // ── DOM helpers ──
  const $ = id => document.getElementById(id);
  const set = (id, html) => { const el = $(id); if (el) el.innerHTML = html; };
  const setText = (id, txt) => { const el = $(id); if (el) el.textContent = txt; };

  // ── Hide loading, show content ──
  document.addEventListener('DOMContentLoaded', () => {
    renderAll();
  });

  function renderAll() {
    renderMeta();
    renderGrade();
    renderScoreRings();
    renderRecruiterSummary();
    renderStrengths();
    renderKeywords();
    renderBullets();
    renderSuggestions();
    renderSectionScores();
    renderSkillGaps();
    renderRoles();
    renderInterviewQuestions();
    hideLoading();
  }

  function renderMeta() {
    setText('metaFileName', meta.fileName || 'Resume');
    setText('metaRole', meta.targetRole ? `→ ${meta.targetRole}` : '');
    const dt = new Date(meta.timestamp);
    setText('metaTime', dt.toLocaleString());
  }

  function renderGrade() {
    const g = A.overall_grade || 'B';
    const el = $('overallGrade');
    if (!el) return;
    el.textContent = g;
    const cls = 'grade-' + g.replace('+', '-plus');
    el.className = 'grade-badge ' + cls;
  }

  // ── Score Rings (Chart.js doughnut) ──
  function renderScoreRings() {
    const scores = [
      { id: 'ringATS',     val: A.ats_score,      label: 'ATS Score',    color: '#8b5cf6', color2: '#4f46e5' },
      { id: 'ringClarity', val: A.clarity_score,   label: 'Clarity',      color: '#06b6d4', color2: '#0891b2' },
      { id: 'ringImpact',  val: A.impact_score,    label: 'Impact',       color: '#10b981', color2: '#059669' },
      { id: 'ringJD',      val: A.jd_match_score,  label: 'JD Match',     color: '#f43f5e', color2: '#be123c' }
    ];

    scores.forEach(({ id, val, label, color, color2 }) => {
      const canvas = $(id);
      if (!canvas) return;
      const score = val !== null && val !== undefined ? Math.round(val) : 0;
      const display = val !== null && val !== undefined ? score : 'N/A';

      // Set value display
      const valueEl = canvas.closest('.score-ring-wrap')?.querySelector('.score-ring-value');
      if (valueEl) {
        const numEl = valueEl.querySelector('.score-num');
        if (numEl) numEl.textContent = display;
      }

      if (val === null || val === undefined) {
        // Draw disabled ring
        new Chart(canvas, {
          type: 'doughnut',
          data: {
            datasets: [{ data: [100], backgroundColor: ['rgba(255,255,255,0.06)'], borderWidth: 0 }]
          },
          options: { cutout: '75%', plugins: { legend: { display: false }, tooltip: { enabled: false } }, animation: false }
        });
        return;
      }

      new Chart(canvas, {
        type: 'doughnut',
        data: {
          datasets: [{
            data: [score, 100 - score],
            backgroundColor: [
              { colorStops: [{ offset: 0, color }, { offset: 1, color: color2 }] },
              'rgba(255,255,255,0.06)'
            ],
            backgroundColor: [color, 'rgba(255,255,255,0.06)'],
            borderWidth: 0,
            borderRadius: 4
          }]
        },
        options: {
          cutout: '75%',
          plugins: { 
            legend: { display: false }, 
            tooltip: { 
              enabled: true,
              callbacks: { label: function(context) { return ` ${label}: ${context.raw}`; } },
              backgroundColor: 'rgba(8,11,20,0.9)',
              titleFont: { family: 'Inter', size: 13 },
              bodyFont: { family: 'Inter', size: 14, weight: 'bold' },
              padding: 10,
              cornerRadius: 8,
              displayColors: false
            } 
          },
          animation: { animateRotate: true, duration: 1200, easing: 'easeOutCubic' },
          hover: { mode: 'index' },
          onHover: (event, chartElement) => {
            event.native.target.style.cursor = chartElement[0] ? 'pointer' : 'default';
          }
        }
      });
    });

    // Update score text values
    setText('scoreATSVal', A.ats_score !== null ? Math.round(A.ats_score) : '—');
    setText('scoreClarityVal', A.clarity_score !== null ? Math.round(A.clarity_score) : '—');
    setText('scoreImpactVal', A.impact_score !== null ? Math.round(A.impact_score) : '—');
    setText('scoreJDVal', A.jd_match_score !== null && A.jd_match_score !== undefined ? Math.round(A.jd_match_score) + '%' : 'N/A');
  }

  // ── Recruiter Summary ──
  function renderRecruiterSummary() {
    setText('recruiterSummaryText', A.recruiter_summary || 'No summary available.');
  }

  // ── Strengths ──
  function renderStrengths() {
    const el = $('strengthsList');
    if (!el) return;
    const strengths = A.strengths || [];
    if (!strengths.length) { el.innerHTML = '<div class="empty-state">No strengths identified.</div>'; return; }
    el.innerHTML = strengths.map(s => `<div class="strength-item">${escHtml(s)}</div>`).join('');
  }

  // ── Keywords ──
  function renderKeywords() {
    const missingEl = $('missingKeywords');
    const presentEl = $('presentKeywords');
    const missing = A.missing_keywords || [];
    const present = A.present_keywords || [];

    if (missingEl) {
      if (!missing.length) {
        missingEl.innerHTML = '<span class="no-keywords">No missing keywords found — great job!</span>';
      } else {
        missingEl.innerHTML = missing.map(k =>
          `<span class="keyword-chip missing">${escHtml(k)}</span>`
        ).join('');
      }
    }

    if (presentEl) {
      if (!present.length) {
        presentEl.innerHTML = '<span class="no-keywords">No keywords detected.</span>';
      } else {
        presentEl.innerHTML = present.map(k =>
          `<span class="keyword-chip present">${escHtml(k)}</span>`
        ).join('');
      }
    }
  }

  function renderBullets() {
    const el = $('bulletsList');
    if (!el) return;
    const bullets = A.weak_bullets || [];
    if (!bullets.length) {
      el.innerHTML = '<div class="no-bullets">🎉 No weak bullets found! Your bullets are strong.</div>';
      return;
    }
    el.innerHTML = bullets.map((b, i) => `
      <div class="bullet-item">
        <div class="bullet-original">
          <span class="bullet-tag original-tag">Before</span>
          <div class="bullet-text">${escHtml(b.original)}</div>
        </div>
        <div class="bullet-improved">
          <span class="bullet-tag improved-tag">After</span>
          <div style="flex:1;">
            <div class="bullet-text" id="bulletText${i}">${escHtml(b.improved)}</div>
            ${b.reason ? `<div class="bullet-reason">💡 ${escHtml(b.reason)}</div>` : ''}
          </div>
          <button class="btn-copy" data-target="bulletText${i}" aria-label="Copy improved bullet">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
            Copy
          </button>
        </div>
      </div>
    `).join('');

    // Attach copy listeners
    el.querySelectorAll('.btn-copy').forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-target');
        const text = $(targetId)?.textContent || '';
        navigator.clipboard.writeText(text).then(() => {
          const originalHtml = btn.innerHTML;
          btn.innerHTML = '✓ Copied';
          btn.style.color = 'var(--emerald-400)';
          setTimeout(() => {
            btn.innerHTML = originalHtml;
            btn.style.color = '';
          }, 2000);
        });
      });
    });
  }

  // ── Suggestions ──
  function renderSuggestions() {
    const el = $('suggestionsList');
    if (!el) return;
    const suggestions = A.top_suggestions || [];
    if (!suggestions.length) { el.innerHTML = '<div class="empty-state">No suggestions.</div>'; return; }
    el.innerHTML = suggestions.map(s => `
      <div class="suggestion-item ${s.priority || 'medium'}">
        <span class="suggestion-priority priority-${s.priority || 'medium'}">${s.priority || 'medium'}</span>
        <div class="suggestion-body">
          <div class="suggestion-category">${escHtml(s.category || '')}</div>
          <div class="suggestion-text">${escHtml(s.suggestion)}</div>
        </div>
      </div>
    `).join('');
  }

  // ── Section Scores ──
  function renderSectionScores() {
    const el = $('sectionScores');
    if (!el) return;
    const ss = A.section_scores || {};
    const items = [
      { key: 'experience', label: 'Experience',  cls: 'fill-violet' },
      { key: 'education',  label: 'Education',   cls: 'fill-cyan' },
      { key: 'skills',     label: 'Skills',      cls: 'fill-emerald' },
      { key: 'formatting', label: 'Formatting',  cls: 'fill-amber' }
    ];
    el.innerHTML = items.map(({ key, label, cls }) => {
      const val = ss[key] !== undefined ? Math.round(ss[key]) : 0;
      return `
        <div class="section-score-item">
          <div class="section-score-header">
            <span class="section-score-name">${label}</span>
            <span class="section-score-val">${val}/100</span>
          </div>
          <div class="section-score-bar">
            <div class="section-score-fill ${cls}" style="width:0%" data-target="${val}%"></div>
          </div>
        </div>
      `;
    }).join('');

    // Animate bars after paint
    requestAnimationFrame(() => {
      setTimeout(() => {
        el.querySelectorAll('.section-score-fill').forEach(bar => {
          bar.style.width = bar.dataset.target;
        });
      }, 300);
    });
  }

  // ── Skill Gaps ──
  function renderSkillGaps() {
    const el = $('skillGapsList');
    if (!el) return;
    const gaps = A.skill_gaps || [];
    if (!gaps.length) { el.innerHTML = '<div class="empty-state">No major skill gaps identified.</div>'; return; }
    el.innerHTML = gaps.map(g => `<span class="skill-gap-chip">${escHtml(g)}</span>`).join('');
  }

  // ── Suggested Roles ──
  function renderRoles() {
    const el = $('rolesList');
    if (!el) return;
    const roles = A.suggested_roles || [];
    const icons = ['💼', '🚀', '⚡', '🎯', '🌟'];
    if (!roles.length) { el.innerHTML = '<div class="empty-state">No role suggestions.</div>'; return; }
    el.innerHTML = roles.map((r, i) => `
      <div class="role-item">
        <span class="role-icon">${icons[i % icons.length]}</span>
        <span class="role-name">${escHtml(r)}</span>
        <span class="role-match">Best Fit</span>
      </div>
    `).join('');
  }

  // ── Interview Questions ──
  function renderInterviewQuestions() {
    const el = $('questionsList');
    if (!el) return;
    const qs = A.interview_questions || [];
    if (!qs.length) { el.innerHTML = '<div class="empty-state">No questions generated.</div>'; return; }
    el.innerHTML = qs.map(q => `<div class="question-item">${escHtml(q)}</div>`).join('');
  }

  // ── Export ──
  const exportPdfBtn = $('exportPDF');
  const exportTxtBtn = $('exportTXT');
  const exportJsonBtn = $('exportJSON');
  const newAnalysisBtn = $('newAnalysis');

  if (exportPdfBtn) {
    exportPdfBtn.addEventListener('click', () => {
      window.print();
    });
  }

  if (exportTxtBtn) {
    exportTxtBtn.addEventListener('click', exportAsText);
  }

  if (exportJsonBtn) {
    exportJsonBtn.addEventListener('click', exportAsJSON);
  }

  if (newAnalysisBtn) {
    newAnalysisBtn.addEventListener('click', () => {
      sessionStorage.removeItem('resume_analysis');
      window.location.href = 'index.html';
    });
  }

  function exportAsText() {
    const lines = [
      '===== AI RESUME ANALYSIS REPORT =====',
      `File: ${meta.fileName}`,
      `Date: ${new Date(meta.timestamp).toLocaleString()}`,
      meta.targetRole ? `Target Role: ${meta.targetRole}` : '',
      '',
      '--- SCORES ---',
      `ATS Score: ${A.ats_score}/100`,
      `Clarity Score: ${A.clarity_score}/100`,
      `Impact Score: ${A.impact_score}/100`,
      A.jd_match_score !== null && A.jd_match_score !== undefined ? `JD Match Score: ${A.jd_match_score}%` : '',
      `Overall Grade: ${A.overall_grade}`,
      '',
      '--- RECRUITER SUMMARY ---',
      A.recruiter_summary || '',
      '',
      '--- STRENGTHS ---',
      ...(A.strengths || []).map((s, i) => `${i + 1}. ${s}`),
      '',
      '--- MISSING KEYWORDS ---',
      (A.missing_keywords || []).join(', '),
      '',
      '--- SKILL GAPS ---',
      ...(A.skill_gaps || []).map((g, i) => `${i + 1}. ${g}`),
      '',
      '--- TOP SUGGESTIONS ---',
      ...(A.top_suggestions || []).map((s, i) => `[${(s.priority || '').toUpperCase()}] ${s.suggestion}`),
      '',
      '--- BULLET IMPROVEMENTS ---',
      ...(A.weak_bullets || []).flatMap(b => [
        `Before: ${b.original}`,
        `After:  ${b.improved}`,
        `Why:    ${b.reason}`,
        ''
      ]),
      '--- SUGGESTED ROLES ---',
      ...(A.suggested_roles || []).map((r, i) => `${i + 1}. ${r}`),
      '',
      '--- INTERVIEW QUESTIONS ---',
      ...(A.interview_questions || []).map((q, i) => `Q${i + 1}: ${q}`),
      '',
      '===== Generated by AI Resume Analyzer ====='
    ].filter(l => l !== null && l !== undefined);

    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resume-analysis-${new Date().getTime()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportAsJSON() {
    const payload = {
      meta: meta,
      analysis: A
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resume-analysis-${new Date().getTime()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // ── Loading overlay ──
  function hideLoading() {
    const overlay = $('loadingOverlay');
    if (overlay) {
      overlay.style.opacity = '0';
      overlay.style.transition = 'opacity 0.5s ease';
      setTimeout(() => overlay.classList.add('hidden'), 500);
    }
  }

  // ── Utility ──
  function escHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

})();
